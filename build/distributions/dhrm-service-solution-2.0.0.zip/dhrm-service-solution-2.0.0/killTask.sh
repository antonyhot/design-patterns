#!/bin/bash
ENV=$1
echo $ENV
LENGTH=`aws ecs list-tasks --cluster dhrm-$ENV --region us-east-1 | jq '.taskArns | length'`

## Interesting it doesn't support below standard loop
#for (( i=0; i<$LENGTH; i++ ))
#do
#   TASK_ARN=`aws ecs list-tasks --cluster dhrm-$ENV | jq ".taskArns[0]" | tr -d '"'`
#   echo start to stop task $TASK_ARN
#    aws ecs stop-task --cluster dhrm-$ENV --task $TASK_ARN
#done

num=0
while [ $num -lt $LENGTH ]
do
    TASK_ARN=`aws ecs list-tasks --cluster dhrm-$ENV --region us-east-1 | jq ".taskArns[0]" | tr -d '"'`
    echo start to stop task $TASK_ARN
    aws ecs stop-task --cluster dhrm-$ENV --task $TASK_ARN --region us-east-1
    let num=num+1
done