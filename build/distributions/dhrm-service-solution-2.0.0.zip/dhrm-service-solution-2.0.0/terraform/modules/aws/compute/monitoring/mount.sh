#!/bin/bash

while [ ! -e /dev/xvdh ]; do sleep 1; done

# check for available device
if lsblk | grep -q -F xvdh; then
     # device exists, check for filesystem
     if sudo file -s /dev/xvdh | grep -q -F "/dev/xvdh: data"; then
          # create physical volumes
          sudo pvcreate /dev/xvdh
          # create the volume group
          sudo vgcreate vg_data /dev/xvdh
          # create the logical volume
          sudo lvcreate --name lv_data --extents 100%FREE vg_data
          # format the logical volume
          sudo mkfs.ext4 /dev/vg_data/lv_data
     fi

     FSTAB_ENTRY="/dev/vg_data/lv_data /data ext4 defaults,noauto 0 0"

     # if entry is not already in /etc/fstab, add it
     if grep -q -F -v "${FSTAB_ENTRY}" /etc/fstab; then
          echo "${FSTAB_ENTRY}" | sudo tee -a /etc/fstab
     fi

     # ensure mount directory exists, then mount the volume
     sudo mkdir -p /data && sudo mount -t ext4 /dev/vg_data/lv_data /data
     
     RCLOCAL_ENTRY="/bin/mount /data &"
     
     # if entry is not already in /etc/rc.local, add it
     if grep -q -F -v "${RCLOCAL_ENTRY}" /etc/rc.local; then
          echo "${RCLOCAL_ENTRY}" | sudo tee -a /etc/rc.local
     fi
fi

