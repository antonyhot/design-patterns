import argparse
import json
import sys
from hashlib import sha256
from hmac import new as hmac

# Used to generate the HMAC signature. Do not modify.
MESSAGE = 'SendRawEmail'
# Version number. Do not modify.
VERSION = '02'.decode("hex")

args = json.load(sys.stdin)
key = args["key"]

# create HMAC-SHA256 signature from AWS secret access key with the version number prepended
digest = VERSION + hmac(str(key), MESSAGE, sha256).digest()
# convert HMAC signature to base 64 for SMTP password
#print "%s" % digest.encode('base64')[:-1]
json.dump({
    "password": "%s" % digest.encode('base64')[:-1],
}, sys.stdout)

