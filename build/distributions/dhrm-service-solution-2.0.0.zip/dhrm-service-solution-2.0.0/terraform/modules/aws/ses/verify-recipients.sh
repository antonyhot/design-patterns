#!/bin/bash

recipients=${1}
# loop over recipients and call verify email
for r in ${recipients//,/ }
do
    aws ses verify-email-identity --email-address ${r}
done
