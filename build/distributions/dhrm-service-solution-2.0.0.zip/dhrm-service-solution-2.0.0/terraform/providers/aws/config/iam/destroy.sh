#!/bin/bash

ENV=$1

if [ x$ENV == x"" ];then
    echo "Please input your environment setting folder, like dev, qc, uat, pse and prod"
    exit 1
fi

terraform apply -auto-approve -input=false -var-file=../../us-east-1/$ENV/alb/terraform.tfvars -lock=false