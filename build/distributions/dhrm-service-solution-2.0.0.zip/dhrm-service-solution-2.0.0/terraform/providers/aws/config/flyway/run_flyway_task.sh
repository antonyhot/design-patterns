#!/bin/bash

# function to loop and check weather or not the flyway container has stopped.
function CheckStatus() {
    if [[ "$STATUS" != "\"STOPPED\"" ]]; then
        sleep ${SLEEP_TIME}s
        CHECK_TASK=$(eval "aws ecs describe-tasks --cluster $CLUSTER --tasks $TASK_ARN --profile role")
        STATUS=$(echo $CHECK_TASK | jq '.tasks[0] .lastStatus')
        FAILURES=$(echo $CHECK_TASK | jq '.failures[]')
        echo "Loop $loop: status is $STATUS"


        if [[ "$STATUS" == "\"STOPPED\"" ]]; then
            return
        else
            loop=$((loop + 1))

            if [[ $loop == $RETRY_COUNT ]]; then
                return
            fi

            CheckStatus
        fi
    fi
}


# Get First two arguments from the command line. If not provided, specify defaults of 15 and 20 respectively
# Note no validation is done to check that this are valid integers in the correct range
SLEEP_TIME=${1:-15}
RETRY_COUNT=${2:-20}

echo "SLEEP_TIME $SLEEP_TIME"
echo "RETRY_COUNT $RETRY_COUNT"


# Get variables
VARS=$(terraform output --json | jq -r 'to_entries | map(select(.value .sensitive == false) | {"key": .key, "value": .value .value}) | from_entries')
CLUSTER=$(echo $VARS | jq -r '.cluster')
TASK_DEF=$(echo $VARS | jq -r '.task_def')
ASSUME_ACCOUNT=$(echo $VARS | jq -r '.assume_account')

# Set up proper role
mkdir -p ~/.aws
cat <<EOF > ~/.aws/config
[profile role]
role_arn = arn:aws:iam::$ASSUME_ACCOUNT:role/terraform_assumed_role
credential_source=Environment
EOF

# Execute task
CHECK_TASK=$(eval "aws ecs run-task --cluster $CLUSTER  --task-definition $TASK_DEF --region $AWS_DEFAULT_REGION --profile role")

STATUS=$(echo $CHECK_TASK | jq '.tasks[0] .lastStatus')
FAILURES=$(echo $CHECK_TASK | jq '.failures[]')
TASK_ARN=$(echo $CHECK_TASK | jq '.tasks[0] .taskArn')

if [[  "$FAILURES" == "" ]]; then
    loop=0
    CheckStatus
fi

EXIT_CODE=$(echo $CHECK_TASK | jq '.tasks[0] .containers[0] .exitCode')

if [[  "$FAILURES" != "" ]]; then
    echo "Task Failures: $FAILURES"
    exit 1
elif [[ "$EXIT_CODE" != 0 ]]; then
    echo "Task exited with exit code $EXIT_CODE"
    exit 1
else
    echo "Task exited successfully"
fi
