#!/bin/bash

ENV=$1

if [ x$ENV == x"" ];then
    echo "Please input your environment setting folder, like dev, qc, uat, pse and prod"
    exit 1
fi

CONFIRM_FLG=""
getConfirmFlag() {
    read -p "Please ensure your aws configuration is configured by using dev aws access id and secret key (Y/N): " CONFIRM_FLG

    if [ x$CONFIRM_FLG != x"Y" ] && [ x$CONFIRM_FLG != x"y" ] && [ x$CONFIRM_FLG != x"N" ] && [ x$CONFIRM_FLG != x"n" ];then
        echo Invalid Input
        getConfirmFlag
    else
        if [ x$CONFIRM_FLG != x"Y" ] && [ x$CONFIRM_FLG != x"y" ];then
            echo Exit!
            exit 0
        else
            echo Start to build terraform
        fi

    fi
}

getConfirmFlag

terraform init -backend-config=../../us-east-1/$ENV/acm/backend.conf -input=false -lock=false
terraform apply -auto-approve -input=false -var-file=../../us-east-1/$ENV/acm/terraform.tfvars -lock=false